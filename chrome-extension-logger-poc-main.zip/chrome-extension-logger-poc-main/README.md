## PoC of logging of roblox security token through malicous chrome extensions, not showing how to use tool to avoid misuse

## Examples
![alt text](examples/cookieFound.png)

![alt text](examples/cookieNotFound.png)
